package com.example.mealprep_v1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class HelpActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)

        val menubutton = findViewById<Button>(R.id.menubutton)
        menubutton.setOnClickListener {
            val Intent = Intent(this, MenuActivity::class.java)
            startActivity(Intent)
        }
        val feedbackbutton = findViewById<Button>(R.id.feedbackBtn)
        feedbackbutton.setOnClickListener {
            val Intent = Intent(this, MenuActivity::class.java)
            startActivity(Intent)
        }
    }
}