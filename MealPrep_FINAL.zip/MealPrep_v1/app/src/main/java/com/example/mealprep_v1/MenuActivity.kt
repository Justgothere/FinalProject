package com.example.mealprep_v1

import android.content.Intent
import android.icu.util.Calendar
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        val helpbutton = findViewById<ImageButton>(R.id.helpbutton)
        helpbutton.setOnClickListener {
            val Intent = Intent(this, MenuActivity::class.java)
            startActivity(Intent)
        }

        val settingsbutton = findViewById<ImageButton>(R.id.settingsbutton)
        settingsbutton.setOnClickListener {
            val Intent = Intent(this, MenuActivity::class.java)
            startActivity(Intent)
        }

        val c = Calendar.getInstance()
        val day= c.get(Calendar.DAY_OF_MONTH)
        val month =c.get(Calendar.MONTH)
        val year =c.get(Calendar.YEAR)
    }
}