package com.example.mealprep_v1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {
    //private lateint var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //setSupportActionBar(toolbar)
        //binding = ActivityMainBinding.inflate(layoutInflater)
        //val view = binding.root
            //setContentView(view)

        val startsurvey = findViewById<Button>(R.id.startsurvey)
        startsurvey.setOnClickListener{
            val Intent = Intent(this,SurveyActivity::class.java)
            startActivity(Intent)
        }

        //fab.setOnClickListener {view ->
            //val activityIntent = Intent(this, SurveyActivity::class.java)
            //activityIntent.putExtra(name: "")
           // startActivity(activityIntent)
        }
    }
